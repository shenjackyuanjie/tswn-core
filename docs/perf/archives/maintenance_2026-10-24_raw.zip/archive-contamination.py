from pathlib import Path
import json
import shutil
base = Path(__file__).resolve().parent
expected = Path("D:/githubs/namer/tswn-core/target/maintenance-bench-20261024").resolve()
assert base.resolve() == expected, base
raw = (base / "raw").resolve(strict=True)
assert raw.parent == expected and raw.name == "raw"
plan = json.loads((base / "contamination-plan.json").read_text(encoding="utf-8"))
archive = base / "contaminated-from-0140"
assert not archive.exists(), archive
archive.mkdir()
names = plan["affected_configurations"]
count = 0
for path in sorted(raw.iterdir()):
    if not any(path.name.startswith(name + "--") for name in names):
        continue
    absolute = path.resolve(strict=True)
    assert absolute.parent == raw and path.is_file(), absolute
    destination = archive / path.name
    assert destination.parent.resolve() == archive.resolve() and not destination.exists()
    shutil.move(str(absolute), str(destination))
    count += 1
shutil.copy2(base / "logs/runner.log", archive / "runner-including-contamination.log")
(archive / "README.md").write_text("# 外部编译污染样本\n\n01:40起存在另一Bevy项目的release构建；01:50左右快照观察到rustc占用约4个核心。\n以01:40为保守边界，将跨过此边界的整项配置（含预热和全部快慢样本）归档，不纳入最终统计；等待外部Cargo进程结束后整项重跑。\n原始元数据中的stdout/stderr路径仍是归档前的raw相对路径，本目录保留同名文件。\n", encoding="utf-8")
print("ARCHIVED", count, "files; CONFIGURATIONS", names)

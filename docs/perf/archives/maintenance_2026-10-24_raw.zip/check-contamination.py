from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
base = Path(__file__).resolve().parent
cutoff = datetime.fromisoformat("2026-10-23T17:40:00+00:00")
groups = {}
for path in (base / "raw").glob("*.json"):
    if any(s in path.name for s in (".samples.", ".report.", ".parquet-hashes.")):
        continue
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or "started_at_utc" not in data:
        continue
    start = datetime.fromisoformat(data["started_at_utc"])
    end = start + timedelta(seconds=data["process_seconds"])
    groups.setdefault(data["name"], []).append((start, end))
result = []
for name, times in sorted(groups.items(), key=lambda kv: min(t[0] for t in kv[1])):
    start, end = min(t[0] for t in times), max(t[1] for t in times)
    affected = end >= cutoff
    print(name, start.astimezone().isoformat(), end.astimezone().isoformat(), "需重跑" if affected else "截止前完成")
    if affected:
        result.append(name)
(base / "contamination-plan.json").write_text(json.dumps({"conservative_cutoff_utc": cutoff.isoformat(), "affected_configurations": result, "observed_external_cargo_pid": 30184, "external_cargo_start_local": "2026-10-24T01:42:17+08:00", "observed_sccache_start_local": "2026-10-24T01:40:28+08:00", "observed_compilation": "Bevy/bevy_egui release，不属于tswn-core", "observed_rustc_cpu_single_core_percent": 416, "policy": "保守以01:40起受影响的整项配置归档，不删慢样本；等待外部进程结束后重跑全部五轮"}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

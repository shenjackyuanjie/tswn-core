$ErrorActionPreference = 'Stop'
Set-Location 'D:/githubs/namer/tswn-core'
$bench = 'D:/githubs/namer/tswn-core/target/maintenance-bench-20261024'
$env:PYTHONUTF8 = '1'
$env:TSWN_BENCH_WEB_SCREENSHOT = '0'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
uv run --no-project --no-cache --python 3.12 C:/Users/shenjack/.agents/skills/noticer-progress/scripts/report_progress.py --state progress --task 'tswn-core 完整性能基准' --message '原生矩阵及PWP生成校验已完成。真实校准缺少state.payload.shield_value，完整manifest正确拒绝，PWP编码项保留失败并单列边界，不补默认常数。继续Web/官方JS参考，然后独立复测和完整正确性门禁。'
python scripts/benchmark_maintenance.py --phase web --resume 2>&1 | Tee-Object "$bench/logs/web-runner.log"
if ($LASTEXITCODE -ne 0) { throw 'Web基准失败' }
python scripts/benchmark_maintenance.py --phase reference --resume 2>&1 | Tee-Object "$bench/logs/reference-runner.log"
if ($LASTEXITCODE -ne 0) { throw '官方JS参考失败' }
python scripts/benchmark_maintenance.py --phase summary 2>&1 | Tee-Object "$bench/logs/summary.log"
if ($LASTEXITCODE -ne 0) { throw '主基准汇总失败' }
& "$bench/followup.ps1"

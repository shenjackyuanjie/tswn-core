import json
from pathlib import Path
import statistics
root = Path(__file__).resolve().parent
rows = {}
for file in (root / "raw").glob("*.json"):
    if any(tag in file.name for tag in (".samples.", ".report.", ".parquet-hashes.")):
        continue
    data = json.loads(file.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or data.get("warmup", True):
        continue
    for row in data.get("metrics", []):
        value = data["process_seconds"] if row.get("use_process_wall") else row["seconds"]
        rows.setdefault(row["key"], {}).setdefault(data["variant"], []).append((data["round"], value, row["signature"]))
for key, variants in sorted(rows.items()):
    if "/case/" in key:
        continue
    old = sorted(variants.get("baseline", []))
    new = sorted(variants.get("current", []))
    if len(old) != 5 or len(new) != 5:
        print(key, "进行中", len(old), len(new))
        continue
    a = statistics.median(x[1] for x in old)
    b = statistics.median(x[1] for x in new)
    paired = [(y[1] / x[1] - 1) * 100 for x, y in zip(old, new)]
    same = len({x[2] for x in old + new}) == 1
    print(f"{key}: {a:.6f} -> {b:.6f}s {(b/a-1)*100:+.2f}% 配对中位{statistics.median(paired):+.2f}% 一致={same}")

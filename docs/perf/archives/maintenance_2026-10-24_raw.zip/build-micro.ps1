$ErrorActionPreference = 'Stop'
$root = 'D:/githubs/namer/tswn-core'
$bench = "$root/target/maintenance-bench-20261024"
Set-Location $root
$env:RUSTC_WRAPPER = ''
$env:CARGO_BUILD_RUSTC_WRAPPER = ''
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '6'
$env:CARGO_TARGET_DIR = "$bench/build"
$env:CARGO_PROFILE_RELEASE_DEBUG = '0'
cargo +nightly fmt --all
if ($LASTEXITCODE -ne 0) { throw 'nightly fmt 失败' }
Copy-Item "$root/crates/tswn_core/examples/perf_maintenance.rs" "$bench/baseline-src/crates/tswn_core/examples/perf_maintenance.rs"
foreach ($variant in @('baseline','current')) {
    $source = if ($variant -eq 'baseline') { "$bench/baseline-src" } else { $root }
    Set-Location $source
    cargo build --locked --release -p tswn_core --no-default-features --features no_debug,png_render,mimalloc_alloc --example perf_maintenance 2>&1 | Tee-Object "$bench/logs/build-$variant-micro.log"
    if ($LASTEXITCODE -ne 0) { throw "微基准构建失败：$variant" }
    Copy-Item "$env:CARGO_TARGET_DIR/release/examples/perf_maintenance.exe" "$bench/$variant/native/perf_maintenance.exe"
    & "$bench/$variant/native/perf_maintenance.exe" --encoder-iters 1 --session-iters 1 --warmup 0 --max-rounds 8 --state-frames 1 > "$bench/logs/micro-smoke-$variant.jsonl"
    if ($LASTEXITCODE -ne 0) { throw "微基准冒烟失败：$variant" }
    Get-ChildItem "$bench/$variant/native","$bench/$variant/wasm-node","$bench/$variant/wasm-web" -File | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 "$bench/$variant/artifact-hashes.json"
}
Set-Location $root
python -m py_compile scripts/benchmark_maintenance.py
if ($LASTEXITCODE -ne 0) { throw '驱动语法失败' }
Write-Host "=== MICRO_BUILD_COMPLETED $(Get-Date -Format o) ==="

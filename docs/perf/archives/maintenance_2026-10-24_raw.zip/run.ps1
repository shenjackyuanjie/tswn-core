$ErrorActionPreference = 'Stop'
Set-Location 'D:/githubs/namer/tswn-core'
$env:PYTHONUTF8 = '1'
$env:RUSTC_WRAPPER = ''
$env:CARGO_BUILD_RUSTC_WRAPPER = ''
python scripts/benchmark_maintenance.py --phase all --resume 2>&1 | Tee-Object target/maintenance-bench-20261024/logs/runner.log
if ($LASTEXITCODE -ne 0) { throw "基准中止，请检查原始日志，退出码 $LASTEXITCODE" }
Write-Host "=== BENCHMARK_COMPLETED $(Get-Date -Format o) ==="

$ErrorActionPreference = 'Stop'
Set-Location 'D:/githubs/namer/tswn-core'
$bench = 'D:/githubs/namer/tswn-core/target/maintenance-bench-20261024'
$env:PYTHONUTF8 = '1'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$other = Get-Process -Id 30184 -ErrorAction SilentlyContinue
if ($null -ne $other) { Write-Host '等待已确认的外部Cargo进程30184结束，不终止它。'; Wait-Process -Id 30184 }
Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cargo.exe','rustc.exe') } | Select-Object Name,ProcessId,ParentProcessId,CreationDate | ConvertTo-Json -Compress | Set-Content -Encoding utf8 "$bench/load-before-resume.json"
uv run --no-project --no-cache --python 3.12 C:/Users/shenjack/.agents/skills/noticer-progress/scripts/report_progress.py --state progress --task 'tswn-core 完整性能基准' --message '外部Cargo构建已结束，受污染的绑定/Openbox配置已整项归档，现在从各配置预热开始重跑五轮；此前已完成的core、score和CLI有效样本保留。'
& "$bench/run.ps1"
if (!(Test-Path "$bench/summary.json")) { throw '主矩阵未完整结束，未开始后续' }
& "$bench/followup.ps1"

"""对PWP生成初测约+3.64%的信号做同参数七轮独立确认。"""
import argparse
from pathlib import Path
import statistics
import sys
sys.path.insert(0, "scripts")
import benchmark_maintenance as b
base = Path(__file__).resolve().parent
runner = b.Runner(argparse.Namespace(bench_dir=base, rounds=7, resume=False))
runner.raw = base / "confirm-pwp/raw"
runner.raw.mkdir(parents=True, exist_ok=True)
runner.pwp()
groups = {}
for path in sorted(runner.raw.glob("*.json")):
    if any(x in path.name for x in (".report.", ".parquet-hashes.")):
        continue
    record = b.load(path)
    if record["warmup"]:
        continue
    for metric in record["metrics"]:
        groups.setdefault(metric["key"], {}).setdefault(record["variant"], []).append({**metric, "round": record["round"]})
rows = []
for key, variants in sorted(groups.items()):
    old = sorted(variants["baseline"], key=lambda x: x["round"])
    new = sorted(variants["current"], key=lambda x: x["round"])
    assert len(old) == len(new) == 7
    a, c = [x["seconds"] for x in old], [x["seconds"] for x in new]
    before, after = statistics.median(a), statistics.median(c)
    paired = [(y / x - 1) * 100 for x, y in zip(a, c)]
    same = len({x["signature"] for x in old + new}) == 1
    row = {"key": key, "baseline_seconds": a, "current_seconds": c,
           "baseline_median_seconds": before, "current_median_seconds": after,
           "change_percent": (after / before - 1) * 100,
           "paired_changes_percent": paired, "paired_median_change_percent": statistics.median(paired),
           "signatures_equal": same, "operations": old[0]["operations"],
           "baseline_mad_percent": statistics.median(abs(x-before) for x in a) / before * 100,
           "current_mad_percent": statistics.median(abs(x-after) for x in c) / after * 100,
           "samples": old[0]["samples"], "baseline_details": old[0], "current_details": new[0]}
    rows.append(row)
    print(key, f"{before:.6f} -> {after:.6f}s {row['change_percent']:+.2f}% 配对{statistics.median(paired):+.2f}% 一致={same}", flush=True)
b.save(base / "confirm-pwp/summary.json", {"rounds": 7, "method": "同初测参数、2700实际对局、20285样本，独立新输出目录；不与初测合并", "metrics": rows})

"""只在全部测量结束后执行：合并原始延迟样本，不平均分位数。"""
from pathlib import Path
import hashlib
import json
import math
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def dist(values):
    values = sorted(values)
    return {"samples": len(values), "p50": values[math.ceil(len(values) * .5) - 1],
            "p95": values[math.ceil(len(values) * .95) - 1], "max": values[-1]}

summary = load(root / "summary.json")
summary["driver_commit"] = "5ec9a29b75f9051803ce53aa5e9178fc56f07be5"
summary["web_driver_commit"] = "80a6452b"
summary["web_configuration"] = {"TSWN_BENCH_WEB_SCREENSHOT": "0", "reason": "计时外截图被当前环境拒绝；两版统一不截图，DOM测量和帧数断言不变"}
summary["limitations"] = load(root / "limitations.json")
summary["contamination"] = load(root / "contamination-plan.json")
summary["confirmations"] = {name: load(root / name / "summary.json") for name in ("confirm-sessions", "confirm-workloads", "confirm-pwp") if (root / name / "summary.json").exists()}
summary["correctness"] = load(root / "correctness/results.json") if (root / "correctness/results.json").exists() else []
summary["correctness_before"] = load(root / "correctness/before.json") if (root / "correctness/before.json").exists() else {}
summary["correctness_after"] = load(root / "correctness/after.json") if (root / "correctness/after.json").exists() else {}
summary["artifacts"] = {v: load(root / v / "artifact-hashes.json") for v in ("baseline", "current")}
summary["pooled_latency_unit"] = "毫秒；nearest-rank，合并全部正式轮原始样本，不平均p95"
pooled = {}
for icons in ("plain", "icons"):
    for variant in ("baseline", "current"):
        files = [root / "raw" / f"python-wasm-session-{icons}--{variant}--r{r}.samples.json" for r in range(1, 6)]
        if not all(p.exists() for p in files):
            continue
        records = [record for p in files for record in load(p)["records"]]
        for fixture in {r["fixture"] for r in records}:
            selected = [r for r in records if r["fixture"] == fixture]
            for backend in ("python", "wasm"):
                runs = [run for r in selected for run in r[f"{backend}_runs"]]
                key = f"{backend}/{icons}/{fixture}/{variant}"
                pooled[key] = {"sessions": len(runs),
                               "result_signatures": sorted({json.dumps((r["frames"], r["winner_ids"], r["rounds_advanced"])) for r in runs}),
                               "create_ms": dist([r["session_create_ms"] for r in runs]),
                               "next_frame_ms": dist([v for r in runs for v in r["next_frame_wall_ms"]]),
                               "total_ms": dist([r["total_session_ms"] for r in runs])}
for variant in ("baseline", "current"):
    files = [root / "raw" / f"web-streaming--{variant}--r{r}" / "baseline.json" for r in range(1, 6)]
    if not all(p.exists() for p in files):
        continue
    runs = [run for p in files for run in load(p)["runs"]]
    for fixture in {r["fixture"] for r in runs}:
        selected = [r for r in runs if r["fixture"] == fixture]
        pooled[f"web/{fixture}/{variant}"] = {
            "sessions": len(selected), "frames_received": sorted({r["frames_received"] for r in selected}),
            "chunks_rendered": sorted({r["chunks_rendered"] for r in selected}),
            "ttis_ms": dist([r["ttis_ms"] for r in selected]), "ttfe_ms": dist([r["ttfe_ms"] for r in selected]),
            "pull_ms": dist([v for r in selected for v in r["pulls"]]),
            "render_ms": dist([v for r in selected for v in r["renders"]]),
        }
summary["pooled_latencies"] = pooled
summary["binding_independent_review"] = load(root / "bindings-review.json")
summary["archive"] = load(root / "archive-index.json")
summary["correctness_final_status"] = load(root / "correctness/final-status.json")
summary["reference_results"] = {p.stem: load(p) for p in sorted((root / "raw").glob("reference-*.report.json"))}
summary["reference_module"] = {"path": "md5.js", "sha256": hashlib.sha256((repo / "md5.js").read_bytes()).hexdigest(), "role": "官方JS横向参考，不是Rust维护前后A/B"}
summary["raw_run_directory"] = str(root.relative_to(repo)).replace(chr(92), "/")
out = repo / "docs/perf/maintenance_2026-10-24_benchmark.json"
out.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("PUBLISHED", out, out.stat().st_size, "metrics", len(summary["metrics"]))
for row in summary["metrics"]:
    if not row["signatures_equal"]:
        print("SIGNATURE_MISMATCH", row["key"])

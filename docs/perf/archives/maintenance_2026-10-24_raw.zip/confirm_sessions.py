"""主矩阵结束后再执行：对图标会话的双向差异做七轮独立确认，不覆盖主样本。"""
import argparse
import json
from pathlib import Path
import statistics
import sys
sys.path.insert(0, "scripts")
import benchmark_maintenance as b
base = Path(__file__).resolve().parent
assert (base / "summary.json").is_file(), "先完成主矩阵，禁止与主bench并行"
runner = b.Runner(argparse.Namespace(bench_dir=base, rounds=7, resume=False))
runner.raw = base / "confirm-sessions/raw"
runner.raw.mkdir(parents=True, exist_ok=True)
name = "core-micro-confirm-sessions"
def parse(out, err, variant, round_no):
    rows = [json.loads(line) for line in out.splitlines() if line]
    assert len(rows) == 16 and all(r["errors"] == 0 for r in rows)
    return [b.metric(name + "/" + row["case"] + "/" + str(row["include_icons"]), row["elapsed_seconds"], b.signature({k: value for k, value in row.items() if k != "elapsed_seconds"}), row["ops"], payload=row) for row in rows if row["workload"] == "battle_session"]
runner.paired(name, lambda variant, round_no: [runner.executable(variant, "perf_maintenance"), "--encoder-iters", "1", "--session-iters", "2000", "--max-rounds", "20000"], parse)
groups = {}
for path in sorted(runner.raw.glob("*.json")):
    record = b.load(path)
    if record["warmup"]:
        continue
    for metric in record["metrics"]:
        groups.setdefault(metric["key"], {}).setdefault(record["variant"], []).append({**metric, "round": record["round"]})
result = []
for key, variants in sorted(groups.items()):
    old = sorted(variants["baseline"], key=lambda x: x["round"])
    new = sorted(variants["current"], key=lambda x: x["round"])
    assert len(old) == len(new) == 7
    a, c = [x["seconds"] for x in old], [x["seconds"] for x in new]
    before, after = statistics.median(a), statistics.median(c)
    paired = [(y / x - 1) * 100 for x, y in zip(a, c)]
    same = len({x["signature"] for x in old + new}) == 1
    row = {"key": key, "baseline_seconds": a, "current_seconds": c,
           "baseline_median_seconds": before, "current_median_seconds": after,
           "change_percent": (after / before - 1) * 100,
           "paired_changes_percent": paired, "paired_median_change_percent": statistics.median(paired),
           "signatures_equal": same}
    result.append(row)
    print(key, f"{before:.6f} -> {after:.6f}s {row['change_percent']:+.2f}% 配对{statistics.median(paired):+.2f}% 一致={same}", flush=True)
b.save(base / "confirm-sessions/summary.json", {"rounds": 7, "sessions_per_case_per_round": 2000, "metrics": result})

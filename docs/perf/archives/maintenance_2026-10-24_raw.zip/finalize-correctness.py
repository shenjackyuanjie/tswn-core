from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import shutil
base = Path(__file__).resolve().parent
folder = base / "correctness"
results_path = folder / "results.json"
results = json.loads(results_path.read_text(encoding="utf-8-sig"))
assert (folder / "after.json").is_file()
original = folder / "initial-results.json"
if not original.exists():
    shutil.copy2(results_path, original)
for row in results:
    if row["name"] == "frontend-pure":
        log = (folder / "frontend-pure-retry.log").read_text(encoding="utf-8-sig")
        assert re.search(r"fail\s+0", log) and "PASS:" in log
        row["initial_exit_code"] = row["exit_code"]
        row["initial_log"] = row["log"]
        row["exit_code"] = 0
        row["log"] = "frontend-pure-retry.log"
        row["scope"] = "DOM播放/主题/盾条等集成断言，不等同于43个纯模块测试"
        row["retry_reason"] = "本次初始监测命令漏传Node VM模块开关；补 --experimental-vm-modules 后实际重跑通过，未修改被测页面"
        row["retry_command"] = ["node", "--experimental-vm-modules", "--test", "scripts/verify_web_playback.mjs"]
        duration = re.search(r"duration_ms\s+([0-9.]+)", log)
        row["retry_elapsed_seconds"] = float(duration[1]) / 1000 if duration else None
for name, filename, expected, command in (
    ("frontend-pure-modules", "frontend-modules.log", "tests 43", ["node", "--test", "crates/tswn_wasm/tests/*.test.mjs"]),
    ("public-api-doc-examples", "public-api-doc-examples.log", "PASS: public API Rust/Python/WASM documentation examples", ["python", "scripts/verify_battle_docs.py"]),
):
    text = (folder / filename).read_text(encoding="utf-8-sig")
    assert expected in text
    if name == "frontend-pure-modules":
        assert re.search(r"fail\s+0", text)
    results.append({"name": name, "exit_code": 0, "log": filename, "command": command})
assert all(row["exit_code"] == 0 for row in results)
results_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
lock = hashlib.sha256((base.parent.parent / "Cargo.lock").read_bytes()).hexdigest()
before = json.loads((folder / "before.json").read_text(encoding="utf-8-sig"))
assert lock.upper() == before["main_lock_sha256"].upper(), "主锁文件发生变化"
status = {"finalized_at_utc": datetime.now(timezone.utc).isoformat(), "checks": len(results), "final_failures": 0,
          "initial_monitor_command_failure": "frontend-pure: 缺少Node --experimental-vm-modules；保留初始日志，带参数重跑通过", "main_lock_sha256": lock,
          "main_lock_unchanged": True}
(folder / "final-status.json").write_text(json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
artifacts = {}
for path in (base.parent / "debug/tswn-cli.exe", base.parent / "debug/tswn_capi.dll", base.parent / "py_cli_api_verify/import/tswn_py/tswn_py.pyd", base.parent / "battle_wasm_node/tswn_wasm_bg.wasm"):
    artifacts[str(path.relative_to(base.parent.parent))] = hashlib.sha256(path.read_bytes()).hexdigest()
(folder / "artifact-hashes.json").write_text(json.dumps(artifacts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(status, ensure_ascii=False, indent=2))

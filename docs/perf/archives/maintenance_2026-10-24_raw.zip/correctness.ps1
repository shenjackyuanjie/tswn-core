$ErrorActionPreference = 'Stop'
$root = 'D:/githubs/namer/tswn-core'
$bench = "$root/target/maintenance-bench-20261024"
Set-Location $root
if (!(Test-Path "$bench/summary.json")) { throw '先完成性能矩阵，正确性构建不得与bench并行' }
$env:RUSTC_WRAPPER = ''
$env:CARGO_BUILD_RUSTC_WRAPPER = ''
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '6'
$env:CARGO_TARGET_DIR = "$bench/build"
$env:CARGO_PROFILE_DEV_DEBUG = '0'
$env:CARGO_PROFILE_TEST_DEBUG = '0'
$env:CARGO_PROFILE_RELEASE_DEBUG = '0'
$env:PYTHONUTF8 = '1'
$env:PYO3_PYTHON = 'D:/apps/cpython/python312/python.exe'
$logRoot = "$bench/correctness"
New-Item -ItemType Directory -Force $logRoot | Out-Null
$hadOpenboxSetting = Test-Path "$root/crates/tswn_openbox/setting"
@{ had_openbox_setting = $hadOpenboxSetting; recorded_at = (Get-Date -Format o); main_lock_sha256 = (Get-FileHash "$root/Cargo.lock").Hash; revision = (& git rev-parse HEAD) } | ConvertTo-Json | Set-Content -Encoding utf8 "$logRoot/before.json"
$results = [Collections.Generic.List[object]]::new()
function Check-Step([string]$name, [scriptblock]$command) {
    $started = Get-Date
    $exitCode = 0
    try {
        & $command 2>&1 | Tee-Object "$logRoot/$name.log"
        $exitCode = $LASTEXITCODE
    } catch {
        $_ | Out-String | Add-Content -Encoding utf8 "$logRoot/$name.log"
        $exitCode = 1
    }
    $results.Add(@{ name = $name; exit_code = $exitCode; started_at = $started.ToString('o'); elapsed_seconds = ((Get-Date) - $started).TotalSeconds; log = "$name.log" })
    $results | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$logRoot/results.json"
    Write-Host "=== CORRECTNESS $name exit=$exitCode ==="
}
Check-Step 'workspace-all-features' { cargo test --workspace --all-features --locked }
Check-Step 'core-no-default-features' { cargo test -p tswn_core --no-default-features --lib --locked }
Check-Step 'release-runtime' { cargo test -p tswn_core runtime --lib --release --locked }
Check-Step 'release-no-debug-runtime' { cargo test -p tswn_core --features no_debug runtime --lib --release --locked }
Check-Step 'release-cli-runtime' { cargo test -p tswn_core --bin tswn-cli runtime --release --locked }
Check-Step 'release-frozen-corpus' { cargo test -p tswn_test --features runtime-corpus --test runtime --release --locked }
Check-Step 'cross-binding-build' { cargo build --locked -p tswn_core -p tswn_capi --bin tswn-cli --lib }
New-Item -ItemType Directory -Force "$root/target/debug","$root/target/battle_wasm_node","$root/target/py_cli_api_verify/import" | Out-Null
Copy-Item "$bench/build/debug/tswn-cli.exe" "$root/target/debug/tswn-cli.exe" -Force
Copy-Item "$bench/build/debug/tswn_capi.dll" "$root/target/debug/tswn_capi.dll" -Force
Copy-Item "$bench/current/wasm-node/*" "$root/target/battle_wasm_node/" -Recurse -Force
Copy-Item "$bench/current/python/tswn_py" "$root/target/py_cli_api_verify/import/" -Recurse -Force
Check-Step 'python-cli-api' { python scripts/verify_py_cli_api.py --skip-build }
Check-Step 'wasm-contract' { node --test scripts/verify_wasm_battle.test.mjs }
Check-Step 'four-binding-exact-payload' { python scripts/verify_battle_cross_binding.py }
Check-Step 'frontend-pure' { node --test scripts/verify_web_playback.mjs }
Check-Step 'python-script-tests' { python -m unittest discover -s scripts -p 'test_*.py' }
Check-Step 'nightly-format' { cargo +nightly fmt --all --check }
Check-Step 'workspace-clippy' { cargo clippy --workspace --all-targets --all-features --locked }
$env:RUSTDOCFLAGS = '-D warnings'
Check-Step 'strict-rustdoc' { cargo doc --workspace --all-features --no-deps --locked }
@{ recorded_at = (Get-Date -Format o); main_lock_sha256 = (Get-FileHash "$root/Cargo.lock").Hash; revision = (& git rev-parse HEAD); had_openbox_setting = $hadOpenboxSetting; now_openbox_setting = (Test-Path "$root/crates/tswn_openbox/setting") } | ConvertTo-Json | Set-Content -Encoding utf8 "$logRoot/after.json"
$bad = @($results | Where-Object { $_.exit_code -ne 0 })
Write-Host "=== CORRECTNESS_COMPLETED failures=$($bad.Count) $(Get-Date -Format o) ==="
if ($bad.Count -ne 0) { throw '存在失败的正确性检查，须查看并处理日志' }

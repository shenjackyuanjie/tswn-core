"""在正确性监测全部结束后留档；测量文本入Git，二进制快照放入既有忽略的dist。"""
from pathlib import Path
import hashlib
import json
import zipfile

base = Path(__file__).resolve().parent
repo = base.parent.parent
assert (base / "correctness/after.json").is_file(), "先完成正确性监测"
assert (base / "summary.json").is_file()
raw_zip = repo / "docs/perf/archives/maintenance_2026-10-24_raw.zip"
binary_zip = repo / "dist/perf/maintenance-2026-10-24-cfee708d/binaries.zip"
assert not raw_zip.exists(), raw_zip
assert not binary_zip.exists(), binary_zip
raw_zip.parent.mkdir(parents=True, exist_ok=True)
binary_zip.parent.mkdir(parents=True, exist_ok=True)

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

text_suffixes = {".json", ".jsonl", ".log", ".md", ".py", ".ps1", ".mjs", ".txt"}
paths = set()
for dirname in ("raw", "logs", "confirm-sessions", "confirm-workloads", "confirm-pwp", "correctness", "contaminated-from-0140", "web-screenshot-failure", "pilot-encoder20000-session100"):
    folder = base / dirname
    if folder.exists():
        paths.update(path for path in folder.rglob("*") if path.is_file() and path.suffix in text_suffixes)
paths.update(path for path in base.iterdir() if path.is_file() and path.suffix in text_suffixes and path.name != "STATE.md")
for variant in ("baseline", "current"):
    paths.add(base / variant / "artifact-hashes.json")
inventory = []
with zipfile.ZipFile(raw_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(paths):
        relative = path.relative_to(base).as_posix()
        archive.write(path, relative)
        inventory.append({"path": relative, "bytes": path.stat().st_size, "sha256": digest(path)})
    for name in ("scripts/benchmark_maintenance.py", "scripts/benchmark_web_streaming.mjs", "scripts/benchmark_py_battle_session.py", "scripts/benchmark_wasm_battle_session.mjs", "crates/tswn_core/examples/perf_maintenance.rs"):
        path = repo / name
        archive.write(path, "drivers/" + name)
        inventory.append({"path": "drivers/" + name, "bytes": path.stat().st_size, "sha256": digest(path)})
    archive.writestr("ARCHIVE-INDEX.json", json.dumps(inventory, ensure_ascii=False, indent=2) + "\n")
    archive.writestr("README.md", "# 维护基准原始证据\n\n包含全部正式与预热轮次、逐调用延迟、失败现场、污染隔离、独立复测和正确性日志。\n不包含可确定性再生的Parquet大数据与可执行文件；二进制另存dist/perf的忽略目录。\n污染与pilot目录只供审计，不纳入正式统计；各阶段数据分别保留，不混合p95或删除慢样本。\n")
with zipfile.ZipFile(raw_zip) as archive:
    assert archive.testzip() is None
with zipfile.ZipFile(binary_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for variant in ("baseline", "current"):
        for path in sorted((base / variant).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                archive.write(path, path.relative_to(base).as_posix())
    archive.writestr("README.md", "# 本机维护前后预构建快照\n\n对应704a1ac9与cfee708d，详细SHA见各variant/artifact-hashes.json。\n从工作区根运行，微基准显式传 --input-dir crates/tswn_test/cases/runtime_stress，避免依赖被cargo clean删除的编译期worktree路径。\n仅供本机复测，不作为发布包；不纳入Git。\n")
with zipfile.ZipFile(binary_zip) as archive:
    assert archive.testzip() is None
index = {"raw_archive": {"path": raw_zip.relative_to(repo).as_posix(), "sha256": digest(raw_zip), "bytes": raw_zip.stat().st_size, "files": len(inventory)},
         "binary_snapshot": {"path": binary_zip.relative_to(repo).as_posix(), "sha256": digest(binary_zip), "bytes": binary_zip.stat().st_size, "tracked": False},
         "omitted": "可确定性再生的Parquet分片、Cargo缓存和PDB不入归档；生成参数、分片SHA、完整日志与元数据保留。"}
(base / "archive-index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(index, ensure_ascii=False, indent=2))

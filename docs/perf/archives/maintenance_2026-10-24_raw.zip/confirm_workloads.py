"""主矩阵后七轮确认可疑的score与CLI pair差异，保持原始样本独立。"""
import argparse
import json
from pathlib import Path
import re
import statistics
import sys
sys.path.insert(0, "scripts")
import benchmark_maintenance as b
base = Path(__file__).resolve().parent
assert (base / "summary.json").is_file(), "先完成主矩阵"
runner = b.Runner(argparse.Namespace(bench_dir=base, rounds=7, resume=False))
runner.raw = base / "confirm-workloads/raw"
runner.raw.mkdir(parents=True, exist_ok=True)
for label, path, runs, timed in (("cqp-hot", b.PLAYERS, 3000, False), ("cqp-timed", b.PLAYERS, 3000, True), ("mario-hot", "docs/perf/score/mario.txt", 50000, False)):
    name = "confirm-score-" + label
    runner.paired(name, lambda v, r: [runner.executable(v, "perf_runtime"), "--mode", "score", "-i", path, "-n", str(runs), "--threads", "1", *(["--timed"] if timed else [])], lambda out, err, v, r: b.runtime_metrics(name, [json.loads(line) for line in out.splitlines() if line]))
name = "confirm-cli-pair"
runner.paired(name, lambda v, r: [runner.executable(v, "tswn-cli"), "bench", "pair", "-p", runner.inputs / "players8.txt", "-l", b.TARGET2, "--teammate-list", runner.inputs / "teammates4.txt", "--head", "3", "-n", "1000", "--keep-rq"], lambda out, err, v, r: [b.metric(name, 0, b.signature(re.sub(r"\t?用时: [^\n]*", "", out)), use_process_wall=True)])
groups = {}
for path in sorted(runner.raw.glob("*.json")):
    record = b.load(path)
    if record["warmup"]:
        continue
    for metric in record["metrics"]:
        value = record["process_seconds"] if metric.get("use_process_wall") else metric["seconds"]
        groups.setdefault(metric["key"], {}).setdefault(record["variant"], []).append({**metric, "seconds": value, "round": record["round"]})
result = []
for key, variants in sorted(groups.items()):
    old = sorted(variants["baseline"], key=lambda x: x["round"])
    new = sorted(variants["current"], key=lambda x: x["round"])
    assert len(old) == len(new) == 7
    a, c = [x["seconds"] for x in old], [x["seconds"] for x in new]
    before, after = statistics.median(a), statistics.median(c)
    paired = [(y / x - 1) * 100 for x, y in zip(a, c)]
    same = len({x["signature"] for x in old + new}) == 1
    row = {"key": key, "baseline_seconds": a, "current_seconds": c,
           "baseline_median_seconds": before, "current_median_seconds": after,
           "change_percent": (after / before - 1) * 100,
           "paired_changes_percent": paired, "paired_median_change_percent": statistics.median(paired),
           "signatures_equal": same, "operations": old[0].get("operations")}
    result.append(row)
    print(key, f"{before:.6f} -> {after:.6f}s {row['change_percent']:+.2f}% 配对{statistics.median(paired):+.2f}% 一致={same}", flush=True)
b.save(base / "confirm-workloads/summary.json", {"rounds": 7, "metrics": result})

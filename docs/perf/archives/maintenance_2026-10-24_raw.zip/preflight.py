import argparse
import sys
from pathlib import Path
sys.path.insert(0, "scripts")
import benchmark_maintenance as b
r = b.Runner(argparse.Namespace(bench_dir=Path("target/maintenance-bench-20261024"), rounds=5, resume=False))
r.prepare_inputs()
print("INPUTS_OK", len(b.load(r.base / "input-hashes.json")))
print("RUNTIME_PAIR_FILE", r.double_groups)
try:
    import pyarrow
    print("PYARROW", pyarrow.__version__)
except ImportError:
    print("PYARROW_MISSING")

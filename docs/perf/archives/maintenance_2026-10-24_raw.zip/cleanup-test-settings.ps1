$ErrorActionPreference = 'Stop'
$root = 'D:/githubs/namer/tswn-core'
$bench = "$root/target/maintenance-bench-20261024"
$before = Get-Content "$bench/correctness/before.json" -Raw | ConvertFrom-Json
if ($before.had_openbox_setting) { throw '测试前已存在配置目录，不清理' }
$folder = (Resolve-Path "$root/crates/tswn_openbox/setting").Path
$expected = [IO.Path]::GetFullPath('D:/githubs/namer/tswn-core/crates/tswn_openbox/setting')
if ($folder -ne $expected) { throw '清理路径不匹配' }
$files = @(Get-ChildItem -LiteralPath $folder -Recurse -File)
$windowStart = [datetime]$before.recorded_at
$windowEnd = $windowStart.AddSeconds(126.04)
if ($files.Count -ne 17) { throw '生成配置文件数发生变化，留待人工检查' }
foreach ($file in $files) {
    if ($file.CreationTime -lt $windowStart -or $file.LastWriteTime -gt $windowEnd) { throw "文件不完全属于本轮测试时段：$($file.FullName)" }
}
@{ path = $folder; reason = '测试前不存在，17个默认配置均由workspace测试时段内生成；用户根setting未触碰'; files = @($files | Select-Object FullName,Length,CreationTime,LastWriteTime); recorded_at = (Get-Date -Format o) } | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$bench/correctness/generated-settings-cleanup.json"
Remove-Item -LiteralPath $folder -Recurse -Force
Write-Host '已清理本轮测试生成的crate内默认配置；未触碰用户根setting。'

$ErrorActionPreference = 'Stop'
Set-Location 'D:/githubs/namer/tswn-core'
$rawPilot = (Resolve-Path 'D:/githubs/namer/tswn-core/target/maintenance-bench-20261024/raw').Path
$expected = [IO.Path]::GetFullPath('D:/githubs/namer/tswn-core/target/maintenance-bench-20261024/raw')
if ($rawPilot -ne $expected) { throw '试跑源目录不匹配' }
$pilotDest = [IO.Path]::GetFullPath('D:/githubs/namer/tswn-core/target/maintenance-bench-20261024/pilot-encoder20000-session100')
if (Test-Path $pilotDest) { throw '试跑归档目标已存在' }
Move-Item -LiteralPath $rawPilot -Destination $pilotDest
python -m py_compile scripts/benchmark_maintenance.py
if ($LASTEXITCODE -ne 0) { throw '驱动语法失败' }
git diff --check
if ($LASTEXITCODE -ne 0) { throw '差异空白检查失败' }
git add -- crates/tswn_core/examples/perf_maintenance.rs scripts/benchmark_maintenance.py scripts/benchmark_web_streaming.mjs
git commit -m "test(perf): 补齐维护前后的串行对照基准"
if ($LASTEXITCODE -ne 0) { throw '基准提交失败' }
git rev-parse HEAD

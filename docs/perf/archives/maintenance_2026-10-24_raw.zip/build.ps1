$ErrorActionPreference = 'Stop'
$root = 'D:/githubs/namer/tswn-core'
$bench = "$root/target/maintenance-bench-20261024"
$base = "$bench/baseline-src"
Set-Location $root
$env:RUSTC_WRAPPER = ''
$env:CARGO_BUILD_RUSTC_WRAPPER = ''
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '6'
$env:CARGO_TARGET_DIR = "$bench/build"
$env:PYTHONUTF8 = '1'
$env:PYO3_PYTHON = 'D:/apps/cpython/python312/python.exe'
$env:CARGO_PROFILE_RELEASE_DEBUG = '0'
$env:CARGO_PROFILE_DEV_DEBUG = '0'
function Checked([scriptblock]$block) {
    & $block
    if ($LASTEXITCODE -ne 0) { throw "原生命令失败，退出码 $LASTEXITCODE" }
}
New-Item -ItemType Directory -Force "$bench/logs" | Out-Null
if (!(Test-Path $base)) { Checked { git worktree add --detach $base 704a1ac9 } }
@{ recorded_at = (Get-Date -Format o); rustc = (& rustc -vV | Out-String); cargo = (& cargo -V); os = (Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber); cpu = (Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors); memory = (Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory); power = (& powercfg /getactivescheme | Out-String); baseline = (& git rev-parse 704a1ac9); current = (& git rev-parse HEAD); build_environment = @{ RUSTC_WRAPPER=''; CARGO_BUILD_RUSTC_WRAPPER=''; CARGO_INCREMENTAL='0'; CARGO_BUILD_JOBS='6'; release_debug='0'; profile='release'; lto='fat'; codegen_units=1; allocator='mimalloc'; features='no_debug,png_render,mimalloc_alloc'; openbox_gui=$false } } | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$bench/environment.json"
foreach ($variant in @('baseline','current')) {
    $source = if ($variant -eq 'baseline') { $base } else { $root }
    $out = "$bench/$variant"
    New-Item -ItemType Directory -Force "$out/native","$out/python/tswn_py","$out/wasm-node","$out/wasm-web" | Out-Null
    Set-Location $source
    Write-Host "=== $variant native $(Get-Date -Format o) ==="
    Checked { cargo build --locked --release -p tswn_core -p tswn_py -p tswn_openbox -p tswn_pwp --no-default-features --features tswn_core/no_debug,tswn_core/png_render,tswn_core/mimalloc_alloc --bin tswn-cli --bin openbox_mem_probe --bin openbox_pair_probe --bin tswn-pwp --example perf_runtime --lib 2>&1 | Tee-Object "$bench/logs/build-$variant-native.log" }
    foreach ($name in @('tswn-cli.exe','openbox_mem_probe.exe','openbox_pair_probe.exe','tswn-pwp.exe','tswn_py.dll')) { Copy-Item "$env:CARGO_TARGET_DIR/release/$name" "$out/native/$name" }
    Copy-Item "$env:CARGO_TARGET_DIR/release/examples/perf_runtime.exe" "$out/native/perf_runtime.exe"
    Copy-Item "$source/crates/tswn_py/tswn_py/*" "$out/python/tswn_py/" -Recurse -Force
    Copy-Item "$env:CARGO_TARGET_DIR/release/tswn_py.dll" "$out/python/tswn_py/tswn_py.pyd"
    Write-Host "=== $variant wasm $(Get-Date -Format o) ==="
    Checked { cargo build --locked --release -p tswn_wasm --target wasm32-unknown-unknown 2>&1 | Tee-Object "$bench/logs/build-$variant-wasm.log" }
    Checked { wasm-bindgen "$env:CARGO_TARGET_DIR/wasm32-unknown-unknown/release/tswn_wasm.wasm" --target nodejs --out-dir "$out/wasm-node" --out-name tswn_wasm }
    Checked { wasm-bindgen "$env:CARGO_TARGET_DIR/wasm32-unknown-unknown/release/tswn_wasm.wasm" --target web --out-dir "$out/wasm-web" --out-name tswn_wasm }
    Get-ChildItem "$out/native","$out/wasm-node","$out/wasm-web" -File | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 "$out/artifact-hashes.json"
}
Set-Location $root
Write-Host "=== BUILD_COMPLETED $(Get-Date -Format o) ==="

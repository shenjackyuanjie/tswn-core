$ErrorActionPreference = 'Stop'
Set-Location 'D:/githubs/namer/tswn-core'
$bench = 'D:/githubs/namer/tswn-core/target/maintenance-bench-20261024'
$main = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -like '*benchmark_maintenance.py --phase all*' })
if ($main.Count -gt 1) { throw '发现多个主bench进程，先核对是否有并行污染' }
if ($main.Count -eq 1) { Wait-Process -Id $main[0].ProcessId }
if (!(Test-Path "$bench/summary.json")) { Write-Host '主矩阵未完整结束，未启动复测和正确性构建。'; return }
uv run --no-project --no-cache --python 3.12 C:/Users/shenjack/.agents/skills/noticer-progress/scripts/report_progress.py --state progress --task 'tswn-core 完整性能基准' --message '主性能矩阵已结束，原始数据已保存；现在串行做七轮独立确认，重点复核图标会话、score和CLI pair差异，之后再启动完整正确性测试。'
python "$bench/confirm_sessions.py" 2>&1 | Tee-Object "$bench/logs/confirm-sessions.log"
if ($LASTEXITCODE -ne 0) { throw '会话复测失败' }
python "$bench/confirm_workloads.py" 2>&1 | Tee-Object "$bench/logs/confirm-workloads.log"
if ($LASTEXITCODE -ne 0) { throw 'score/pair复测失败' }
uv run --no-project --no-cache --python 3.12 C:/Users/shenjack/.agents/skills/noticer-progress/scripts/report_progress.py --state progress --task 'tswn-core 完整性能基准' --message '主矩阵和独立复测已完成，性能测量结束；现在启动workspace全feature测试、无默认feature测试、release/no_debug与冻结corpus、Python/C/WASM四端精确一致性监测，所有日志单独留档。'
& "$bench/correctness.ps1"
Write-Host "=== FOLLOWUP_COMPLETED $(Get-Date -Format o) ==="
